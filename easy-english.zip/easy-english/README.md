# Easy English

Open `index.html` in VS Code, then use the Live Server extension (Go Live), or double-click it to open in a browser.

- `css/style.css` : design (colors, layout)
- `js/app.js` : all lesson data (arrays `U`, `A1`, `LD`, `QA`) and page logic

To add lessons, edit the `U` array in `js/app.js` (each unit has 3 lessons, vocabulary words and a quiz question).
Login is a demo stored in the browser (localStorage). A real login needs a PHP + MySQL backend.

- `images/` : SVG banners for levels (A1–B2), units and skill pages
- Levels page: A1 = starter pages; A2 = Units 1-3; B1 = Units 4-7; B2 = Units 8-10 (edit `LV` in `js/app.js`)

## Publish
Upload this whole folder to Netlify / GitHub Pages / Cloudflare Pages (HTTPS). Then on a phone: Chrome > Install app, Safari > Share > Add to Home Screen.
