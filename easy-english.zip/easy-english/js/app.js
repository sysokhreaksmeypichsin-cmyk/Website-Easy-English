const $=id=>document.getElementById(id);
let st={done:{},fav:[],best:0,days:[],user:null,txt:{}};
try{st=Object.assign(st,JSON.parse(localStorage.getItem("ee2")||"{}"))}catch(e){}
const save=()=>{try{localStorage.setItem("ee2",JSON.stringify(st))}catch(e){}};
const D=Math.floor(Date.now()/864e5);
function say(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang="en-US";u.rate=.85;speechSynthesis.speak(u)}catch(e){}}
const mq=(q,ch)=>`<div class="q" ${ch?'data-ch="1"':""}><b>${q[0]}</b>${q[1].map((o,j)=>`<button data-c="${+(j==q[2])}">${o}</button>`).join("")}<span></span></div>`;
const sp=t=>`<button class="btn o" data-say="${t.replace(/"/g,"&quot;")}">🔊</button>`;

/* ===== DATA ===== */
const A1=[["Apple","ផ្លែប៉ោម","I eat an apple every day."],["Book","សៀវភៅ","This is my book."],["Bag","កាបូប","My bag is blue."],["Water","ទឹក","I drink water."],["House","ផ្ទះ","My house is small."],["Teacher","គ្រូ","The teacher is kind."],["Friend","មិត្តភក្តិ","He is my friend."],["Rice","បាយ","We eat rice."]];
/* unit: [title,km,words,lessons[[title,cando,grammar,rule,example]],communication,writing,quiz] */
const U=[
["Friends","មិត្តភក្តិ",[["friendly","រួសរាយ","My neighbour is friendly."],["shy","ខ្មាស់អៀន","He is shy in class."],["honest","ស្មោះត្រង់","Be honest with me."]],[
["1.1 A lot in common?","Encourage further conversation by showing interest","Auxiliary verbs (do, be, have)","Use do, be and have to make questions, negatives and tenses.","Do you like music? She is working."],
["1.2 How many friends?","Start a conversation with a stranger","Present Simple and Present Continuous","Habits use Present Simple; actions happening now use Present Continuous.","I walk to work, but today I am taking the bus."],
["1.3 Brotherly love?","Retell a simple narrative in your own words","Present Perfect Simple and Past Simple","Present Perfect links the past to now; Past Simple is for a finished time.","I have met Sam. I met him in 2020."]],
"Describe a friend","Write a semi-formal email introducing yourself",["Right now, I ___ to my friend.",["talk","am talking","talks"],1]],
["Media","ប្រព័ន្ធផ្សព្វផ្សាយ",[["channel","ឆានែល","Change the channel."],["headline","ចំណងជើងព័ត៌មាន","I read the headline."],["documentary","ភាពយន្តឯកសារ","We watched a documentary."]],[
["2.1 Silver screen","Give opinions and agree or disagree","Defining relative clauses","Use who, which or that to say which person or thing.","The actor who won is my favourite."],
["2.2 Built to last","Describe an object","The passive","Use be + past participle when the action matters more than the doer.","The bridge was built in 1990."],
["2.3 Stories in the news","Describe an important event from your life","Past Simple and Past Continuous","Past Continuous gives the background; Past Simple gives the main event.","I was reading when the phone rang."]],
"Describe a film","Write a description of an event",["This phone ___ in Japan.",["makes","is made","making"],1]],
["Lifestyle","របៀបរស់នៅ",[["crowded","ចង្អៀតណែន","The market is crowded."],["quiet","ស្ងាត់","The village is quiet."],["modern","ទំនើប","It is a modern city."]],[
["3.1 Your place or mine?","Make a complaint","Future plans","Use going to or Present Continuous for plans.","We are visiting Siem Reap next week."],
["3.2 City life","Compare cities","Comparatives and superlatives","-er or more compares two; -est or most shows the top one.","This road is longer than that one."],
["3.3 Eco-homes","Take notes while listening","Future possibility","Use might, may or could for things that are possible.","It might rain tomorrow."]],
"Talk about hopes, dreams and ambitions","Write an email of complaint",["Tokyo is ___ city I have visited.",["bigger","the biggest","biggest"],1]],
["Wealth","ទ្រព្យសម្បត្តិ",[["save","សន្សំ","I save money."],["borrow","ខ្ចី","Can I borrow a pen?"],["salary","ប្រាក់ខែ","His salary is good."]],[
["4.1 Catch me if you can","Use intonation to check and confirm information","Question tags","Add a short question at the end to check information.","You live here, don’t you?"],
["4.2 Getting rich quick","Carry out a survey and present results","Modal verbs of obligation and prohibition","must and have to mean necessary; mustn’t means forbidden.","You mustn’t park here."],
["4.3 Spend more!","Ask for and give clarification","Zero and First Conditionals","Zero is for facts; First is for real future results.","If I save, I will buy a bike."]],
"Give reasons for opinions","Write a report on factual information",["If it rains, we ___ at home.",["stay","will stay","stayed"],1]],
["Free time","ពេលទំនេរ",[["recipe","រូបមន្តធ្វើម្ហូប","This recipe is easy."],["delicious","ឆ្ងាញ់","The soup is delicious."],["ingredient","គ្រឿងផ្សំ","Salt is an ingredient."]],[
["5.1 Are you creative?","Describe your response to a picture","Present Perfect Continuous and Simple","Continuous stresses the activity; Simple stresses the result.","I have been painting all day. I have painted three pictures."],
["5.2 Time well spent?","Describe a pastime","Verb patterns with -ing and infinitive","Some verbs take -ing, others take to + verb.","I enjoy swimming. I want to swim."],
["5.3 Memorable meals","Describe a restaurant","Countable and uncountable nouns","Use many with countable nouns and much with uncountable ones.","How much rice? How many eggs?"]],
"Make a short presentation","Write a detailed description of an object",["We don’t have ___ rice.",["many","much","a few"],1]],
["Holidays","វិស្សមកាល",[["luggage","ឥវ៉ាន់","My luggage is heavy."],["passport","លិខិតឆ្លងដែន","Show your passport."],["sightseeing","ដើរកម្សាន្ត","We went sightseeing."]],[
["6.1 Across Africa","Describe a memorable photo","Past Perfect Simple","had + past participle shows the earlier past action.","The bus had left when we arrived."],
["6.2 Down under","Get around a new place","Uses of like","like can be a verb, a preposition or part of a question.","What is it like? It looks like a bird."],
["6.3 Travellers’ tales","Talk about unexpected events","Articles","a/an for one of many, the for a known thing.","I saw a dog. The dog was big."]],
"Suggest and respond to ideas","Write a detailed description of a place",["When I got there, they ___ already eaten.",["have","had","has"],1]],
["Learning","ការរៀនសូត្រ",[["lesson","មេរៀន","Today’s lesson is easy."],["exam","ការប្រឡង","The exam is on Monday."],["practise","អនុវត្ត","I practise every day."]],[
["7.1 Learning from experience","Describe a learning experience","Subject and object questions","In subject questions we do not use do or did.","Who called you? Who did you call?"],
["7.2 Great teachers","Describe a teacher from your past","Used to and would","Both talk about past habits; only used to works for past states.","I used to live in Takeo."],
["7.3 It’s never too late","Carry out an interview","Modals of ability, past and present","can, could and be able to talk about ability.","She could swim at five."]],
"Discuss options and make a decision","Summarise a short article",["She ___ play the piano when she was young.",["use to","used to","uses to"],1]],
["Change","ការផ្លាស់ប្តូរ",[["improve","កែលម្អ","I want to improve."],["decision","ការសម្រេចចិត្ត","It was a hard decision."],["rule","ច្បាប់","Follow the rule."]],[
["8.1 Changing the rules","Discuss problems and suggest changes","Second Conditional","If + past simple, would + verb for unreal situations.","If I were rich, I would travel."],
["8.2 Change the world","Express and respond to opinions","Adverbs","Adverbs describe verbs, adjectives or other adverbs.","He speaks slowly and very clearly."],
["8.3 Making the right decisions","Describe the effect of important decisions","Third Conditional","If + past perfect, would have + participle for past regrets.","If I had studied, I would have passed."]],
"Express and respond to feelings","Write a personal email about change",["If I ___ rich, I would travel the world.",["am","were","will be"],1]],
["Jobs","ការងារ",[["employer","និយោជក","My employer is kind."],["skill","ជំនាញ","Typing is a useful skill."],["experience","បទពិសោធន៍","She has work experience."]],[
["9.1 Freedom at work","Ask for clarification","make, let, allow","make + person + verb; let + person + verb; allow + person + to.","My boss lets us leave early."],
["9.2 Skills and experience","Take notes while listening","Reported speech","The tense usually moves one step back.","She said she was busy."],
["9.3 New on the job","Describe job skills","Past obligation and permission","had to = necessary; was allowed to = permitted.","We had to wear uniforms."]],
"Answer interview questions","Write a formal email or letter of application",["She said, “I am busy.” → She said she ___ busy.",["is","was","will be"],1]],
["Memories","ការចងចាំ",[["childhood","កុមារភាព","I loved my childhood."],["remember","ចងចាំ","I remember her smile."],["memory","ការចងចាំ","I have a good memory."]],[
["10.1 Childhood memories","Respond to a poem","I wish / If only","I wish + past simple for present regrets.","I wish I had more time."],
["10.2 Memorable people","Briefly describe a famous person","Review of past tenses","Choose the tense by the order of events.","I had eaten before she called."],
["10.3 Saying goodbye","Understand cultural differences","Phrasal verbs","A verb + particle often has a special meaning.","Please look after your sister."]],
"Talk about memories","Write a simple essay",["I wish I ___ more time.",["have","had","will have"],1]]];
const X=[
[["","Intonation in echo questions","Unusual hobbies · Not in my culture…"],["Personality","Sounds and spelling ‘ea’; start a conversation with a stranger","A best friend · How many friends should you have?"],["Arguing","","Falling out with someone · Brotherly love?"]],
[["","Give opinions and agree or disagree","Man on Wire · Dubbing or subtitling in foreign language films"],["Television","Describe an object; sounds /n/ and /ŋ/","Eco-gadgets · Completely reliable… and built to last"],["","Word stress on word endings","The news · News stories"]],
[["","Complain politely","Yourhome-Myhome · A home exchange · Problems with the home exchange"],["Adjectives describing places","","City I love · Kyoto, Japan · Why not move to …?"],["Compound nouns","Word stress in compound nouns","What does the future hold? · Future predictions"]],
[["Phrasal verbs","Intonation in question tags","The true story of a real fake · Frank Abagnale · The Ghost test"],["Personal qualities (1) · Shopping","Connected speech; report survey results","Duncan Bannatyne · A seminar on entrepreneurial qualities · Good with money"],["","Ask for clarification","How you are persuaded to buy more · Behavioural advertising"]],
[["","Describe your response to a picture; weak forms","Describing paintings · 3 ways to become more creative"],["Describing pastimes","Sounds and spelling ‘a’","Hannah Cheung – film-maker · Reviews"],["Food","Describe a restaurant","The world’s best restaurant · A restaurant in Bruges"]],
[["Descriptive language","Describe a memorable photo","Extract from Travels Across Africa · Travel photos"],["Places in a city","Get around a new place; intonation in questions","Travelling around Australia · Dannii Minogue in Melbourne"],["Travelling","Sentence stress","Lady Mary Wortley Montagu · Strange things happen when you travel…"]],
[["Learning","Describe a learning experience","Learning experiences · Mistakes that work…"],["Personal qualities (2) · Word building","Word stress in word building","Extract from Matilda · Memorable teachers"],["Education","Connected speech; carry out an interview","U3A · It’s never too late · Old age"]],
[["The law · Cities","Discuss problems and suggest changes","The Forbidden Apple · Edinburgh and Madrid"],["Global issues","Sounds and spelling ‘o’; express attitude and respond to opinions","Comic marathon man raises £200,000 · Changes in the world"],["Life decisions","Sentence stress in the Third Conditional","Your life, your decisions · Important decisions"]],
[["","Intonation for pausing; ask for clarification and deal with difficult questions","Jobs · Senco · A talk"],["-ed and -ing adjectives","","Management styles · The Engineer and the Manager"],["Job requirements","","Operatunity · Different jobs"]],
[["","","It was long ago · Childhood memory · Erma Bombeck"],["Biographies","Pronouncing numbers; say numbers","Some famous people · The Making of ___ · Gianni Versace"],["","Word stress in phrasal verbs; say goodbye (in person)","We’re letting you go · Some goodbyes · Saying goodbye on the phone"]]];
const xr=(i,j)=>{const x=X[i][j];return (x[0]?`📚 <b>Vocabulary:</b> ${x[0]}<br>`:"")+(x[1]?`🗣️ <b>Speaking and pronunciation:</b> ${x[1]}<br>`:"")+(x[2]?`🎧📖 <b>Listening and reading:</b> ${x[2]}<br>`:"")};
const PS=["He ___ English every day.",["study","studies","studying"],1];
const ALLQ=[PS,...U.map(u=>u[6])];
const LD=[[["Hello, I’m Sokha. What’s your name?","Hi Sokha, I’m Dara. Nice to meet you.","Where are you from?","I’m from Battambang."],["Where is Dara from?",["Phnom Penh","Battambang","Siem Reap"],1]],[["Excuse me, where is the market?","Go straight, then turn left.","Is it far?","No, it’s five minutes on foot."],["How far is the market?",["5 minutes","1 hour","1 day"],0]]];
const QA=[["What is your name?","My name is Sokha."],["Where are you from?","I’m from Cambodia."],["How are you today?","I’m fine, thank you."],["What do you do?","I’m a student."]];
const RS="Dara lives in a small village. Every morning he walks to school with his friend Sokha. They love reading books.";
const RK="ដារ៉ារស់នៅក្នុងភូមិតូចមួយ។ រៀងរាល់ព្រឹកគាត់ដើរទៅសាលាជាមួយមិត្តភក្តិឈ្មោះសុខា។ ពួកគេចូលចិត្តអានសៀវភៅ។";
const VL=[["Daily Words (A1)",A1],...U.map((u,i)=>[`Unit ${i+1} ${u[0]}`,u[2].map(w=>w.slice())])];
let vi=0,QZ=null;
const wcard=w=>`<div class="card"><b style="font-size:20px">${w[0]}</b> <button class="btn o" data-say="${w[0]}">🔊</button> <button class="btn o" data-fav="${w[0]}">${st.fav.includes(w[0])?"⭐":"☆"}</button><br><span class="km">${w[1]}</span><br><i>${w[2]}</i></div>`;
const lessons=()=>U.reduce((n,u)=>n+u[3].length,0);

/* ===== LANGUAGE (EN / ខ្មែរ) and THEME (light / dark) ===== */
const TR={"Home":"ទំព័រដើម","Levels":"កម្រិត","Units":"មេរៀន","Vocabulary":"ពាក្យ","Grammar":"វេយ្យាករណ៍","Listening":"ការស្តាប់","Speaking":"ការនិយាយ","Reading":"ការអាន","Writing":"ការសរសេរ","Quiz":"កម្រងសំណួរ","Dashboard":"វឌ្ឍនភាព","Account":"គណនី","Get started":"ចាប់ផ្តើម","View Lessons":"មើលមេរៀន","Start Learning":"ចាប់ផ្តើមរៀន","Book Units":"មេរៀនក្នុងសៀវភៅ","Categories":"ប្រភេទមេរៀន","Daily Word":"ពាក្យប្រចាំថ្ងៃ","Daily Challenge":"សំណួរប្រចាំថ្ងៃ","Mark as completed":"សម្គាល់ថារៀនចប់","✔ Completed":"✔ រៀនចប់","Open lessons →":"បើកមេរៀន →","Lesson":"មេរៀន","Next →":"បន្ទាប់ →","Try again":"ព្យាយាមម្តងទៀត","Log out":"ចាកចេញ","Daily Words":"ពាក្យប្រចាំថ្ងៃ","Basic Grammar":"វេយ្យាករណ៍មូលដ្ឋាន","Dialogues":"ការសន្ទនា","Short Reading":"ការអានខ្លី","Create account / Log in":"បង្កើតគណនី / ចូល","Guest":"ភ្ញៀវ",
"THE FUN AND EASY WAY TO LEARN ENGLISH!":"វិធីរៀនភាសាអង់គ្លេសដ៏សប្បាយ និងងាយស្រួល!",
"Learn English the easy way with A1–B2 lessons, Khmer meanings, quizzes and daily practice, anytime, anywhere.":"រៀនភាសាអង់គ្លេសឱ្យងាយ ជាមួយមេរៀនកម្រិត A1–B2 អត្ថន័យខ្មែរ កម្រងសំណួរ និងការហ្វឹកហាត់ប្រចាំថ្ងៃ គ្រប់ពេល គ្រប់ទីកន្លែង។"};
const dark=()=>st.theme?st.theme=="dark":matchMedia("(prefers-color-scheme:dark)").matches;
function applyLang(){document.documentElement.dataset.theme=dark()?"dark":"light";document.documentElement.lang=st.lang=="km"?"km":"en";
$("th").textContent=dark()?"☀️":"🌙";$("lg").textContent=st.lang=="km"?"🇰🇭 ខ្មែរ":"🇬🇧 EN";
const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){if(n.parentNode.closest("script,style"))continue;if(n._o===undefined)n._o=n.nodeValue;const k=n._o.trim(),km=st.lang=="km"&&TR[k];n.nodeValue=km?n._o.replace(k,km):n._o}}
/* ===== SIGN IN / CREATE ACCOUNT (accounts are stored in this browser only) ===== */
let gm="in",dip=null;
addEventListener("beforeinstallprompt",e=>{e.preventDefault();dip=e;gate()});
const G={en:{eye:"YOUR SPACE TO LEARN",t1:"Welcome back",t2:"Create your account",s1:"Sign in to continue your lessons.",s2:"Join free and start learning English today.",nm:"Name",nmp:"Your name",em:"Email",pw:"Password",pwp:"At least 8 characters",in:"Sign in",up:"Create account",q1:"New to Easy English?",q2:"Already have an account?",l1:"Create an account",l2:"Sign in",ins:"Install Easy English on this device",ios:"On iPhone: tap Share, then Add to Home Screen",foot:"Your account is saved on this device only.",e1:"Enter a valid email.",e2:"Password must be at least 8 characters.",e3:"Enter your name.",e4:"Email or password is incorrect.",e5:"This email already has an account."},
km:{eye:"កន្លែងសម្រាប់រៀនរបស់អ្នក",t1:"សូមស្វាគមន៍ការត្រឡប់មកវិញ",t2:"បង្កើតគណនីរបស់អ្នក",s1:"ចូលគណនីដើម្បីបន្តមេរៀនរបស់អ្នក។",s2:"ចូលរួមដោយឥតគិតថ្លៃ ហើយចាប់ផ្តើមរៀនភាសាអង់គ្លេសថ្ងៃនេះ។",nm:"ឈ្មោះ",nmp:"ឈ្មោះរបស់អ្នក",em:"អ៊ីមែល",pw:"ពាក្យសម្ងាត់",pwp:"យ៉ាងតិច ៨ តួអក្សរ",in:"ចូលគណនី",up:"បង្កើតគណនី",q1:"ថ្មីនៅ Easy English?",q2:"មានគណនីរួចហើយ?",l1:"បង្កើតគណនី",l2:"ចូលគណនី",ins:"ដំឡើង Easy English លើឧបករណ៍នេះ",ios:"លើ iPhone៖ ចុច Share រួចចុច Add to Home Screen",foot:"គណនីរបស់អ្នករក្សាទុកលើឧបករណ៍នេះតែប៉ុណ្ណោះ។",e1:"សូមបញ្ចូលអ៊ីមែលឲ្យត្រឹមត្រូវ។",e2:"ពាក្យសម្ងាត់ត្រូវមានយ៉ាងតិច ៨ តួអក្សរ។",e3:"សូមបញ្ចូលឈ្មោះរបស់អ្នក។",e4:"អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ។",e5:"អ៊ីមែលនេះមានគណនីរួចហើយ។"}};
const esc=x=>x.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const U2=()=>{try{return JSON.parse(localStorage.getItem("ee_users")||"{}")}catch(e){return{}}};
async function H(x){if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(x));return[...new Uint8Array(b)].map(v=>v.toString(16).padStart(2,"0")).join("")}let h=5381;for(const c of x)h=(h*33^c.charCodeAt(0))>>>0;return""+h}
function gate(){let g=$("gate");if(st.user&&!U2()[st.user.k]){st.user=null;save()}
if(st.user){g&&g.remove();return}
const t=G[st.lang=="km"?"km":"en"],up=gm=="up";
if(!g){g=document.createElement("div");g.id="gate";document.body.appendChild(g)}
const ios=/iphone|ipad/i.test(navigator.userAgent)&&!navigator.standalone;
g.innerHTML=`<div class="gc"><div class="gtop"><button class="pill" id="glg">${st.lang=="km"?"🇰🇭 ខ្មែរ":"🇬🇧 EN"}</button></div><div class="glogo"><i>E</i>Easy English</div><div class="eye">${t.eye}</div><h1>${up?t.t2:t.t1}</h1><p class="gs">${up?t.s2:t.s1}</p>${up?`<label>${t.nm}</label><input id="gn" placeholder="${t.nmp}" autocomplete="name">`:""}<label>${t.em}</label><input id="ge" type="email" placeholder="you@example.com" autocomplete="email"><label>${t.pw}</label><input id="gp" type="password" placeholder="${t.pwp}" autocomplete="${up?"new-password":"current-password"}"><div class="gerr" id="gerr"></div><button class="gbtn" id="gok">${up?t.up:t.in}</button><p class="gq">${up?t.q2:t.q1} <a href="#" id="gsw">${up?t.l2:t.l1}</a></p>${dip?`<button class="gins" id="gin">⬇ ${t.ins}</button>`:ios?`<p class="gnote">${t.ios}</p>`:""}<p class="gnote">${t.foot}</p></div>`;
$("glg").onclick=()=>{st.lang=st.lang=="km"?"en":"km";save();render()};
$("gsw").onclick=e=>{e.preventDefault();gm=up?"in":"up";gate()};
if($("gin"))$("gin").onclick=async()=>{dip.prompt();await dip.userChoice;dip=null;gate()};
g.querySelectorAll("input").forEach(i=>i.onkeydown=e=>{if(e.key=="Enter")$("gok").click()});
$("gok").onclick=async()=>{const err=m=>{$("gerr").textContent=m},em=$("ge").value.trim().toLowerCase(),pw=$("gp").value,nm=up?$("gn").value.trim():"";
if(!/^\S+@\S+\.\S+$/.test(em))return err(t.e1);if(up&&!nm)return err(t.e3);if(pw.length<8)return err(t.e2);
const us=U2();let u;
if(up){if(us[em])return err(t.e5);const salt=Math.random().toString(36).slice(2);u=us[em]={name:esc(nm),salt,h:await H(salt+pw)};try{localStorage.setItem("ee_users",JSON.stringify(us))}catch(x){}}
else{u=us[em];if(!u||u.h!==await H(u.salt+pw))return err(t.e4)}
st.user={name:u.name,email:esc(em),k:em};save();location.hash="#home";render()}}
const img=(n,a)=>`<img class="pic" src="images/${n}.svg" alt="${a}" loading="lazy">`;
/* level: [code,name,km,description,unitIndexes] — A2/B1/B2 follow the grammar difficulty of the book units */
const LV=[["A1","Beginner","ចាប់ផ្តើម","Greetings, daily words and simple sentences (Starter pages).",[]],
["A2","Elementary","បឋម","Present tenses, past simple, comparatives and future plans.",[0,1,2]],
["B1","Intermediate","មធ្យម","Conditionals, modals, passive, present perfect continuous and verb patterns.",[3,4,5,6]],
["B2","Upper-Intermediate","មធ្យមខ្ពស់","Third conditional, reported speech, wish / if only and review of past tenses.",[7,8,9]]];
let lv=0;
/* ===== PAGES ===== */
const P={
levels:()=>{const L=LV[lv],tabs=LV.map((v,i)=>`<button class="btn ${i==lv?"":"o"}" data-lv="${i}">${v[0]}</button>`).join("");
const body=L[4].length?L[4].map(i=>{const u=U[i];return `<div class="card" style="margin:10px 0">${img("unit-"+(i+1),u[0])}<b>Unit ${i+1}: ${u[0]}</b> <span class="km">${u[1]}</span><ul>${u[3].map(l=>`<li>${l[0]} — ${l[2]}</li>`).join("")}</ul><a class="btn" href="#units">Open lessons →</a></div>`}).join(""):`<div class="grid">${[["vocab","Daily Words"],["grammar","Basic Grammar"],["listen","Dialogues"],["speak","Speaking"],["read","Short Reading"]].map(c=>`<a class="card" href="#${c[0]}">${img("page-"+c[0],c[1])}<b>${c[1]}</b></a>`).join("")}</div>`;
return `<h2>🪜 Levels · កម្រិត A1–B2</h2><div class="row">${tabs}</div>${img("level-"+L[0],L[0])}<h3>${L[0]} · ${L[1]} <span class="km">${L[2]}</span></h3><p>${L[3]}</p>${body}`},
home:()=>{const w=A1[D%A1.length],q=ALLQ[D%ALLQ.length],t=st.days.includes(D);return `
<section class="hero2"><div class="h2t"><h1>THE FUN AND EASY WAY TO LEARN ENGLISH!</h1><p>Learn English the easy way with A1–B2 lessons, Khmer meanings, quizzes and daily practice, anytime, anywhere.</p><a class="btn big" href="#levels">Get started</a> <a class="btn o big" href="#units">View Lessons</a></div><div class="h2v"><div class="phone"><div class="notch"></div><div class="logo" style="margin:34px 0 14px">Easy <b>English</b></div><div class="avs"><i style="background:#ef6b6b">👩‍🏫</i><i style="background:#6ee7a0">🧑‍🎓</i><i style="background:#fcd34d">💂</i><i style="background:#93a0f0">👨‍💼</i><i class="more">+5</i></div><div class="chat"><div class="bub">Hello! What’s your name?</div><div class="bub me">My name is Dara.</div><div class="sk"></div><div class="sk s"></div></div></div><span class="fl f1">🎙️</span><span class="fl f2">✨</span></div></section>
<h3>Categories</h3><div class="grid">${[["vocab","📚","Vocabulary","ពាក្យ"],["grammar","✏️","Grammar","វេយ្យាករណ៍"],["listen","🎧","Listening","ការស្តាប់"],["speak","🗣️","Speaking","ការនិយាយ"],["read","📖","Reading","ការអាន"],["write","📝","Writing","ការសរសេរ"],["levels","🪜","Levels","កម្រិត A1 · A2 · B1 · B2"],["units","🎓","Book Units","មេរៀន ១០ ជំពូក"],["quiz","🧠","Quiz","កម្រងសំណួរ"]].map(c=>`<a class="card" href="#${c[0]}"><span style="font-size:28px">${c[1]}</span><br><b>${c[2]}</b><br><span class="km">${c[3]}</span></a>`).join("")}</div>
<div class="grid"><div class="card"><span class="tag">Daily Word</span><h3 style="margin-top:8px">${w[0]} ${sp(w[0])}</h3><span class="km">${w[1]}</span><br><i>${w[2]}</i></div>
<div class="card"><span class="tag">Daily Challenge</span> ${t?"✅ Done today":""}${mq(q,1)}</div></div>`},

units:()=>`<h2>📘 Book Units · មេរៀនទាំង ១០ ជំពូក</h2><p class="km">Topics follow the uploaded Students’ Book (3 lessons per unit). Examples are original. Tick each lesson when finished.</p>`+U.map((u,i)=>`<details ${i?"":"open"}><summary>Unit ${i+1}: ${u[0]} · <span class="km">${u[1]}</span></summary>${img("unit-"+(i+1),u[0])}`+u[3].map((l,j)=>{const k=i+"-"+j;return `<div class="card" style="margin:10px 0"><b>${l[0]}</b> <span class="tag">${l[3-0]?"":""}Lesson</span><br>🎯 ${l[1]}<br>${xr(i,j)}✏️ <b>${l[2]}</b>: ${l[3]}<br>💬 <i>${l[4]}</i> ${sp(l[4])}<div class="row" style="margin-top:8px"><button class="btn ${st.done[k]?"":"o"}" data-done="${k}">${st.done[k]?"✔ Completed":"Mark as completed"}</button></div></div>`}).join("")+`<p>🗣️ <b>Communication:</b> ${u[4]}<br>📝 <b>Writing:</b> ${u[5]}</p></details>`).join(""),

vocab:()=>`<h2>📚 Vocabulary · ពាក្យថ្មី</h2>${img("page-vocab","Vocabulary")}<div class="row">${VL.map((v,i)=>`<button class="btn ${i==vi?"":"o"}" data-vl="${i}">${i?v[0]:"Lesson 01 · "+v[0]}</button>`).join("")}</div><div class="grid">${VL[vi][1].map(wcard).join("")}</div>`,

grammar:()=>`<h2>✏️ Grammar · វេយ្យាករណ៍</h2>${img("page-grammar","Grammar")}<span class="tag">A1 Starter</span>
<details open><summary>Present Simple Tense</summary><p class="km">ប្រើសម្រាប់សកម្មភាពប្រចាំថ្ងៃ ឬទម្លាប់។</p><ul><li>I go to school.</li><li>She studies English.</li><li>They play football.</li></ul>${mq(PS)}</details>
<details><summary>Past Simple Tense</summary><p class="km">ប្រើសម្រាប់ហេតុការណ៍ដែលបានកើតឡើងរួចហើយ។</p><p>I visited Siem Reap last year.</p></details>
<details><summary>Future Simple Tense</summary><p class="km">ប្រើ will + កិរិយាសព្ទ សម្រាប់អនាគត។</p><p>We will travel tomorrow.</p></details>
<details><summary>Parts of Speech</summary><p>Noun · នាម | Verb · កិរិយាសព្ទ | Adjective · គុណនាម | Adverb · កិរិយាវិសេសន៍ | Pronoun · សព្វនាម | Preposition · បុព្វបទ | Conjunction · ឈ្នាប់</p></details>
<h3>Book grammar points (30)</h3>`+U.map((u,i)=>u[3].map(l=>`<details><summary>${l[2]} <span class="km">· Unit ${i+1}</span></summary><p>${l[3]}</p><p><i>${l[4]}</i> ${sp(l[4])}</p></details>`).join("")).join(""),

listen:()=>`<h2>🎧 Listening · ការស្តាប់</h2>${img("page-listen","Listening")}`+LD.map((d,i)=>`<div class="card" style="margin:10px 0"><b>Dialogue ${i+1}</b> <button class="btn" data-dlg="${i}">▶ Play</button><details><summary>Transcript</summary>${d[0].map((l,k)=>`<p><b>${k%2?"B":"A"}:</b> ${l}</p>`).join("")}</details>${mq(d[1])}</div>`).join(""),

speak:()=>`<h2>🗣️ Speaking · ការនិយាយ</h2>${img("page-speak","Speaking")}`+QA.map(q=>`<div class="card" style="margin:8px 0"><b>${q[0]}</b> ${sp(q[0])}<br>→ ${q[1]} ${sp(q[1])}</div>`).join("")+`<div class="card"><b>🎙️ Record your voice · ថតសំឡេង</b><div class="row"><button class="btn" id="rb">● Record</button></div><audio id="ra" controls style="width:100%;margin-top:8px;display:none"></audio><p class="km" id="rm"></p></div>`,

read:()=>`<h2>📖 Reading · ការអាន</h2>${img("page-read","Reading")}<div class="card"><p>${RS}</p><details><summary>ខ្មែរ · Khmer translation</summary><p>${RK}</p></details>${sp(RS)}</div>${mq(["How does Dara go to school?",["He walks","By bus","By bike"],0])}`,

write:()=>{const o=U.map((u,i)=>`<option value="${i}">Unit ${i+1}: ${u[5]}</option>`).join("");return `<h2>📝 Writing · ការសរសេរ</h2>${img("page-write","Writing")}<select id="wsel">${o}</select><textarea id="wta" placeholder="Write here… សរសេរនៅទីនេះ"></textarea><div class="row"><button class="btn" data-ws="1">💾 Save</button><span id="wc" class="km"></span></div>`},

quiz:()=>{if(!QZ)QZ={l:[...ALLQ].sort(()=>Math.random()-.5).slice(0,5),i:0,s:0,a:false};
if(QZ.i>=QZ.l.length){if(QZ.s>st.best){st.best=QZ.s;save()}return `<h2>🧠 Quiz result</h2><div class="card"><h1>${QZ.s} / ${QZ.l.length}</h1><p>Best score: ${st.best}/5 · ពិន្ទុខ្ពស់បំផុត</p><button class="btn" data-qr="1">Try again</button></div>`}
const q=QZ.l[QZ.i];return `<h2>🧠 Quiz · Question ${QZ.i+1}/${QZ.l.length}</h2><div class="card"><b>${q[0]}</b>${q[1].map((o,j)=>`<button class="opt" data-qa="${j}">${o}</button>`).join("")}<p id="qf"></p><button class="btn hide" id="qn" style="display:none" data-qn="1">Next →</button></div>`},

dash:()=>{const n=Object.keys(st.done).length,t=lessons(),pc=Math.round(n/t*100);return `<h2>📊 Dashboard · វឌ្ឍនភាព</h2>
<div class="card"><b>${st.user?"Hello, "+st.user.name+" 👋":"Guest"}</b><p>Lessons completed: ${n} / ${t} (${pc}%)</p><div class="bar"><i style="width:${pc}%"></i></div></div>
<div class="grid"><div class="card">🏆 Best quiz score<h2>${st.best}/5</h2></div><div class="card">🔥 Daily challenges done<h2>${st.days.length}</h2></div><div class="card">📝 Writings saved<h2>${Object.keys(st.txt).length}</h2></div></div>
<h3>⭐ Favorites</h3><div class="grid">${st.fav.length?st.fav.map(f=>{const w=VL.flatMap(v=>v[1]).find(x=>x[0]==f);return w?wcard(w):""}).join(""):"<p class='km'>No favorites yet. Tap ☆ in Vocabulary.</p>"}</div>`},

login:()=>`<h2>👤 Login / Register</h2><div class="card" style="max-width:420px">${st.user?`<p>Signed in as <b>${st.user.name}</b> (${st.user.email})</p><button class="btn o" data-lo="1">Log out</button>`:`<input id="un" placeholder="Name · ឈ្មោះ"><input id="ue" placeholder="Email">
<button class="btn" data-li="1">Create account / Log in</button>`}<p class="km" style="font-size:13px">Demo account saved only in this browser. Real accounts need a PHP + MySQL backend.</p></div>`
};
const NAV=[["home","Home"],["levels","Levels"],["units","Units"],["vocab","Vocabulary"],["grammar","Grammar"],["listen","Listening"],["speak","Speaking"],["read","Reading"],["write","Writing"],["quiz","Quiz"],["dash","Dashboard"],["login","Account"]];
function render(){const p=(location.hash.slice(1)||"home");const pg=P[p]?p:"home";
$("nav").innerHTML=NAV.map(n=>`<a href="#${n[0]}" class="${n[0]==pg?"on":""}">${n[1]}</a>`).join("");
$("app").innerHTML=P[pg]();window.scrollTo(0,0);
if(pg=="write")loadW();applyLang();gate()}
function loadW(){$("wta").value=st.txt[$("wsel").value]||"";$("wc").textContent=""}
addEventListener("hashchange",()=>{QZ=null;render()});

/* ===== EVENTS ===== */
let rec,ch=[];
$("app").onclick=async e=>{const t=e.target.closest("button,[data-say]");if(!t)return;const d=t.dataset;
if(d.say){say(d.say);return}
if(d.c!==undefined){const q=t.parentNode;if(q.dataset.d)return;const ok=d.c==="1";t.classList.add(ok?"ok":"no");q.querySelector("span").textContent=ok?"✅ ត្រឹមត្រូវ / Correct!":"❌ ព្យាយាមម្តងទៀត / Try again";if(ok){q.dataset.d=1;if(q.dataset.ch&&!st.days.includes(D)){st.days.push(D);save()}}return}
if(d.fav){st.fav=st.fav.includes(d.fav)?st.fav.filter(x=>x!=d.fav):[...st.fav,d.fav];save();t.textContent=st.fav.includes(d.fav)?"⭐":"☆";return}
if(d.done){st.done[d.done]?delete st.done[d.done]:st.done[d.done]=1;save();render();return}
if(d.lv!==undefined){lv=+d.lv;render();return}
if(d.vl){vi=+d.vl;render();return}
if(d.dlg){speechSynthesis.cancel();LD[d.dlg][0].forEach((l,i)=>{const u=new SpeechSynthesisUtterance(l);u.lang="en-US";u.pitch=i%2?1.4:.8;u.rate=.85;speechSynthesis.speak(u)});return}
if(d.ws){const k=$("wsel").value;if($("wta").value.trim()){st.txt[k]=$("wta").value;save();$("wc").textContent="💾 Saved · រក្សាទុករួច"}return}
if(d.qa!==undefined){if(QZ.a)return;QZ.a=true;const q=QZ.l[QZ.i],ok=+d.qa===q[2];if(ok)QZ.s++;document.querySelectorAll(".opt").forEach((b,j)=>{if(j==q[2])b.classList.add("ok");else if(b==t)b.classList.add("no")});$("qf").textContent=ok?"✅ Correct!":"❌ Correct answer: "+q[1][q[2]];$("qn").style.display="inline-block";return}
if(d.qn){QZ.i++;QZ.a=false;render();return}
if(d.qr){QZ=null;render();return}
if(d.li){const n=$("un").value.trim(),m=$("ue").value.trim();if(n&&m){st.user={name:n,email:m};save();render()}return}
if(d.lo){st.user=null;save();render();return}
if(t.id=="rb"){if(rec&&rec.state=="recording"){rec.stop();return}
try{const s=await navigator.mediaDevices.getUserMedia({audio:true});rec=new MediaRecorder(s);ch=[];rec.ondataavailable=x=>ch.push(x.data);
rec.onstop=()=>{s.getTracks().forEach(k=>k.stop());const a=$("ra");a.src=URL.createObjectURL(new Blob(ch));a.style.display="block";t.textContent="● Record"};
rec.start();t.textContent="■ Stop"}catch(x){$("rm").textContent="Microphone not available here · មិនអាចប្រើមីក្រូហ្វូន"}}};
$("app").onchange=e=>{if(e.target.id=="wsel")loadW()};
$("th").onclick=()=>{st.theme=dark()?"light":"dark";save();applyLang()};
$("lg").onclick=()=>{st.lang=st.lang=="km"?"en":"km";save();render()};
render();